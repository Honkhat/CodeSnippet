#include "MainWnd.h"

CMainWnd::CMainWnd(void):m_pBtnHorzLay(nullptr),m_pBtnVertLay(nullptr),m_pLayHorz(nullptr),m_pLayVert(nullptr)

{

}


CMainWnd::~CMainWnd(void)
{
}

const CDuiString& CMainWnd::GetResourcePath()
{
	return g_sResourcePath;
}

CDuiString CMainWnd::GetSkinFolder()
{
	return _T("MainWnd");
}

CDuiString CMainWnd::GetSkinFile() 
{
	return _T("MainWnd.xml");
}

LPCTSTR CMainWnd::GetWindowClassName() const 
{
	return _T("CMainWnd"); 
}

void CMainWnd::InitWindow()
{
	m_pBtnHorzLay = dynamic_cast<CButtonUI*>(m_PaintManager.FindControl(_T("btnHorzLayout")));
	m_pBtnVertLay = dynamic_cast<CButtonUI*>(m_PaintManager.FindControl(_T("btnVertLayout")));
	m_pLayHorz = dynamic_cast<CHorizontalLayoutUI*>(m_PaintManager.FindControl(_T("layConHorz")));
	m_pLayVert = dynamic_cast<CVerticalLayoutUI*>(m_PaintManager.FindControl(_T("layConVert")));
	
}


void CMainWnd::Notify(TNotifyUI& msg)
{
	if(msg.sType == DUI_MSGTYPE_CLICK)
	{
		if(msg.pSender->GetName() == "closebtn")
			::PostQuitMessage(0);
		else if(m_pBtnHorzLay == msg.pSender)
			OnUI_BtnHorzLay();
		else if(m_pBtnVertLay == msg.pSender)
			OnUI_BtnVertLay();
	}
	
}

void CMainWnd::OnUI_BtnHorzLay()
{
	SwitchParentNode(m_pLayHorz, m_pLayVert);
}

void CMainWnd::OnUI_BtnVertLay()
{
	SwitchParentNode(m_pLayVert, m_pLayHorz);
}

void CMainWnd::SwitchParentNode(CContainerUI* pDestCon, CContainerUI* pSrcCon)
{
	if(!pDestCon || !pSrcCon)
		return;

	pSrcCon->SetVisible(false);
	pSrcCon->SetAutoDestroy(false);
	for(int i = 0; i < pSrcCon->GetCount(); ++i)
	{
		CControlUI* pItem = pSrcCon->GetItemAt(i);
		pDestCon->Add(pItem);
	}
	pSrcCon->RemoveAll();
	pDestCon->SetVisible(true);
	//pDestCon->SetPos(pDestCon->GetPos());
}